# Flutter Android APK Project

এই ফোল্ডারটি Flutter project root। এখানে `pubspec.yaml` আছে এবং Dart source `lib/` ফোল্ডারে রাখা হয়েছে।

## ফোল্ডার কাঠামো
- `pubspec.yaml` — Flutter package/dependency config
- `lib/main.dart` — Chat UI, Coding Agent UI, Settings ও Admin Dashboard UI
- `lib/auth.dart` — Login/Register এবং Session
- `lib/app_config.dart` — API URL ও Theme constants

## APK বানানোর আগে
1. কম্পিউটারে Flutter SDK ও Android SDK/Android Studio ইনস্টল করুন।
2. Backend deploy করে HTTPS API URL তৈরি করুন।
3. এই Flutter ফোল্ডারকে project root হিসেবে খুলুন।
4. Terminal/Command Prompt-এ নিচের কমান্ড চালান।

### Windows
```bat
set API_URL=https://YOUR-BACKEND-DOMAIN
flutter pub get
flutter create --platforms=android .
flutter build apk --release --dart-define=API_URL=%API_URL%
```
অথবা `API_URL` সেট করে `make_apk_windows.bat` চালান।

### Linux/macOS
```bash
export API_URL=https://YOUR-BACKEND-DOMAIN
chmod +x make_apk.sh
./make_apk.sh
```

APK তৈরি হলে পাবেন:
`build/app/outputs/flutter-apk/app-release.apk`

Android Emulator-এ local backend পরীক্ষা করতে:
`flutter run --dart-define=API_URL=http://10.0.2.2:8000`

বাস্তব Android ফোনে `10.0.2.2` ব্যবহার করবেন না; deploy করা HTTPS API URL দিন।
